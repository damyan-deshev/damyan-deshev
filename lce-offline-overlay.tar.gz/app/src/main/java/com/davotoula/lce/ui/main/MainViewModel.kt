package com.davotoula.lce.ui.main

import android.app.Application
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import androidx.core.net.toUri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.davotoula.lce.R
import com.davotoula.lce.VideoDetailsModel
import com.davotoula.lce.data.VideoSettingsPreferences
import com.davotoula.lce.getFileSize
import com.davotoula.lce.ui.Codec
import com.davotoula.lightcompressor.CompressionListener
import com.davotoula.lightcompressor.Resolution
import com.davotoula.lightcompressor.VideoCodec
import com.davotoula.lightcompressor.VideoCompressor
import com.davotoula.lightcompressor.config.Configuration
import com.davotoula.lightcompressor.config.SaveLocation
import com.davotoula.lightcompressor.config.SharedStorageConfiguration
import com.davotoula.lightcompressor.config.VideoResizer
import com.davotoula.lightcompressor.video.GifToMp4Converter
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Suppress("TooManyFunctions")
class MainViewModel(
    application: Application,
) : AndroidViewModel(application) {
    companion object {
        private const val BITRATE_MIN_KBPS = 100
        private const val BITRATE_MAX_KBPS = 50000
        private const val BITRATE_4K_KBPS = 8000
        private const val BITRATE_1080P_KBPS = 4000
        private const val BITRATE_720P_KBPS = 2000
        private const val BITRATE_540P_KBPS = 1500
        private const val BITRATE_LOW_KBPS = 1000
        private const val RESOLUTION_4K = 2160
        private const val RESOLUTION_1080P = 1080
        private const val RESOLUTION_720P = 720
        private const val RESOLUTION_540P = 540
        private const val H265_BITRATE_MULTIPLIER = 0.75
        private const val KBPS_TO_BPS = 1000L
        private const val PERCENT_DIVISOR = 100f
    }

    private val _uiState = MutableStateFlow(MainUiState())

    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<MainEvent>()
    val events: SharedFlow<MainEvent> = _events.asSharedFlow()

    private val context get() = getApplication<Application>()
    private val originalVideoSizes = mutableMapOf<Int, Long>()
    private val videoSettingsPreferences = VideoSettingsPreferences(application)
    private val gifJobs = mutableListOf<Job>()

    init {
        loadSavedSettings()
    }

    private fun loadSavedSettings() {
        viewModelScope.launch {
            val settings = videoSettingsPreferences.settings.first()
            _uiState.update { state ->
                state.copy(
                    selectedResolution = settings.resolution,
                    customResolutionInput = settings.resolution.shortSide.toString(),
                    selectedCodec = settings.codec,
                    isStreamableEnabled = settings.isStreamableEnabled,
                    bitrateKbps = settings.bitrateKbps ?: state.bitrateKbps,
                    bitrateInput = settings.bitrateKbps?.toString() ?: state.bitrateInput,
                )
            }
            if (settings.bitrateKbps == null) {
                calculateAutoBitrate()
            }
        }
    }

    private fun saveSettings() {
        viewModelScope.launch {
            val state = _uiState.value
            videoSettingsPreferences.saveSettings(
                resolution = state.selectedResolution,
                codec = state.selectedCodec,
                isStreamableEnabled = state.isStreamableEnabled,
                bitrateKbps = state.bitrateKbps,
            )
        }
    }

    fun onAction(action: MainAction) {
        when (action) {
            is MainAction.SelectVideos -> handleSelectVideos(action.uris)
            is MainAction.SetResolution -> handleSetResolution(action.resolution)
            is MainAction.SetCustomResolution -> handleSetCustomResolution(action.pixels)
            is MainAction.SetCustomResolutionInput -> handleSetCustomResolutionInput(action.value)
            is MainAction.SetCodec -> handleSetCodec(action.codec)
            is MainAction.SetStreamable -> handleSetStreamable(action.enabled)
            is MainAction.SetBitrate -> handleSetBitrate(action.kbps)
            is MainAction.SetBitrateInput -> handleSetBitrateInput(action.value)
            MainAction.CalculateAutoBitrate -> calculateAutoBitrate()
            MainAction.StartCompression -> startCompression()
            MainAction.CancelCompression -> cancelCompression()
            is MainAction.PlayVideo -> handlePlayVideo(action.path)
            MainAction.ClearToast -> clearToast()
            MainAction.ToggleSettings -> handleToggleSettings()
        }
    }

    private fun handleToggleSettings() {
        _uiState.update { it.copy(isSettingsExpanded = !it.isSettingsExpanded) }
    }

    private fun handleSelectVideos(uris: List<Uri>) {
        if (uris.isEmpty()) return

        originalVideoSizes.clear()
        val pendingStatus = context.getString(R.string.status_pending)
        _uiState.update { state ->
            state.copy(
                pendingUris = uris,
                videos =
                    uris.map { uri ->
                        VideoDetailsModel(
                            playableVideoPath = null,
                            uri = uri,
                            newSize = pendingStatus,
                            progress = 0f,
                        )
                    },
                errorMessage = null,
                isSettingsExpanded = false,
            )
        }

        // Auto-calculate bitrate when videos are selected
        calculateAutoBitrate()
    }

    private fun handleSetResolution(resolution: Resolution) {
        _uiState.update { state ->
            state.copy(
                selectedResolution = resolution,
                customResolution = null,
                customResolutionInput = resolution.shortSide.toString(),
            )
        }
        calculateAutoBitrate()
        saveSettings()
    }

    private fun handleSetCustomResolution(pixels: Int) {
        _uiState.update { state ->
            state.copy(
                customResolution = pixels,
                customResolutionInput = pixels.toString(),
            )
        }
        calculateAutoBitrate()
    }

    private fun handleSetCustomResolutionInput(value: String) {
        val pixels = parsePositiveInt(value)
        _uiState.update { state ->
            state.copy(
                customResolutionInput = value,
                customResolution = pixels,
            )
        }
        if (pixels != null) {
            calculateAutoBitrate()
        }
    }

    private fun handleSetCodec(codec: Codec) {
        val effectiveCodec =
            if (codec == Codec.H265 && !isH265Supported()) {
                showToast(context.getString(R.string.h265_not_supported_fallback))
                Codec.H264
            } else {
                codec
            }

        _uiState.update { state ->
            state.copy(selectedCodec = effectiveCodec)
        }
        calculateAutoBitrate()
        saveSettings()
    }

    private fun handleSetStreamable(enabled: Boolean) {
        _uiState.update { state ->
            state.copy(isStreamableEnabled = enabled)
        }
        saveSettings()
    }

    private fun handleSetBitrate(kbps: Int) {
        _uiState.update { state ->
            val clamped = kbps.coerceIn(BITRATE_MIN_KBPS, BITRATE_MAX_KBPS)
            state.copy(
                bitrateKbps = clamped,
                bitrateInput = clamped.toString(),
            )
        }
        saveSettings()
    }

    private fun handleSetBitrateInput(value: String) {
        val kbps = parsePositiveInt(value)
        _uiState.update { state ->
            state.copy(
                bitrateInput = value,
                bitrateKbps = kbps?.coerceIn(BITRATE_MIN_KBPS, BITRATE_MAX_KBPS) ?: state.bitrateKbps,
            )
        }
    }

    private fun calculateAutoBitrate() {
        val state = _uiState.value
        val shortSide = state.customResolution ?: state.selectedResolution.shortSide

        // Calculate recommended bitrate based on short side resolution and codec
        // H.265 typically achieves same quality at ~40% lower bitrate
        val baseBitrate =
            when {
                shortSide >= RESOLUTION_4K -> BITRATE_4K_KBPS
                shortSide >= RESOLUTION_1080P -> BITRATE_1080P_KBPS
                shortSide >= RESOLUTION_720P -> BITRATE_720P_KBPS
                shortSide >= RESOLUTION_540P -> BITRATE_540P_KBPS
                else -> BITRATE_LOW_KBPS
            }

        // H.265 typically saves ~25% over H.264 at equivalent quality
        val codecMultiplier = if (state.selectedCodec == Codec.H265) H265_BITRATE_MULTIPLIER else 1.0
        val recommendedBitrate = (baseBitrate * codecMultiplier).toInt()

        _uiState.update {
            it.copy(
                bitrateKbps = recommendedBitrate,
                bitrateInput = recommendedBitrate.toString(),
            )
        }
    }

    private fun parsePositiveInt(value: String): Int? = value.toIntOrNull()?.takeIf { it > 0 }

    @Suppress("ReturnCount")
    private fun startCompression() {
        val state = _uiState.value

        if (state.pendingUris.isEmpty()) {
            showToast(context.getString(R.string.no_videos_selected))
            return
        }

        if (state.isCompressing) {
            showToast(context.getString(R.string.compression_in_progress))
            return
        }

        // Split pendingUris into GIFs (handled by GifToMp4Converter directly with
        // no secondary compression) and videos (existing VideoCompressor pipeline).
        // We remember the original index so callbacks can update the right row in
        // state.videos regardless of which sub-pipeline ran.
        val resolver = context.contentResolver
        val videoOriginalIndices = mutableListOf<Int>()
        val gifOriginalIndices = mutableListOf<Int>()
        state.pendingUris.forEachIndexed { index, uri ->
            val mime = resolver.getType(uri)?.lowercase()
            if (mime == "image/gif") {
                gifOriginalIndices += index
            } else {
                videoOriginalIndices += index
            }
        }

        val videoUris = videoOriginalIndices.map { state.pendingUris[it] }
        val resolutionPixels = (state.customResolution ?: state.selectedResolution.shortSide).toDouble()
        val videoCodec =
            when (state.selectedCodec) {
                Codec.H264 -> VideoCodec.H264
                Codec.H265 -> if (isH265Supported()) VideoCodec.H265 else VideoCodec.H264
            }

        _uiState.update { it.copy(isCompressing = true, errorMessage = null) }

        // Kick off GIF conversions. Each coroutine updates the row at its
        // originalIndex, then checks if the whole batch is complete.
        gifJobs.clear()
        for (originalIndex in gifOriginalIndices) {
            val uri = state.pendingUris[originalIndex]
            val job =
                viewModelScope.launch {
                    runGifConversion(originalIndex, uri)
                }
            gifJobs += job
        }

        if (videoUris.isEmpty()) {
            // No videos left for VideoCompressor — GIF coroutines drive completion.
            return
        }

        val videoNames =
            List(videoUris.size) { subIndex ->
                "compressed_${System.currentTimeMillis()}_${videoOriginalIndices[subIndex]}"
            }

        val configuration =
            Configuration.withBitrateInBps(
                isMinBitrateCheckEnabled = false,
                videoBitrateInBps = state.bitrateKbps.toLong() * KBPS_TO_BPS,
                resizer = VideoResizer.limitShortSide(resolutionPixels),
                videoNames = videoNames,
                videoCodec = videoCodec,
            )

        VideoCompressor.start(
            context = context,
            uris = videoUris,
            isStreamable = state.isStreamableEnabled,
            storageConfiguration =
                SharedStorageConfiguration(
                    saveAt = SaveLocation.MOVIES,
                    subFolderName = "lce-compressed",
                ),
            configureWith = configuration,
            listener =
                object : CompressionListener {
                    override fun onStart(index: Int) {
                        val originalIndex = videoOriginalIndices[index]
                        viewModelScope.launch {
                            val originalSize = getOriginalVideoSize(videoUris[index])
                            originalVideoSizes[originalIndex] = originalSize
                            Log.i(
                                "MainViewModel",
                                "Original video size for index $originalIndex: ${getFileSize(originalSize)}",
                            )
                            updateVideoProgress(
                                originalIndex,
                                0f,
                                context.getString(R.string.status_compressing),
                            )
                        }
                    }

                    override fun onSuccess(
                        index: Int,
                        size: Long,
                        path: String?,
                    ) {
                        val originalIndex = videoOriginalIndices[index]
                        viewModelScope.launch {
                            val originalSize =
                                originalVideoSizes[originalIndex]
                                    ?: getOriginalVideoSize(videoUris[index])

                            if (originalSize in 1..<size) {
                                Log.w(
                                    "MainViewModel",
                                    "Compressed video ($size bytes) is larger than" +
                                        " original ($originalSize bytes). Not saving.",
                                )
                                path?.let { deleteCompressedFile(it) }
                                showToast(
                                    context.getString(
                                        R.string.video_not_saved_larger_toast,
                                        getFileSize(size),
                                        getFileSize(originalSize),
                                    ),
                                )
                                updateVideoNotSaved(originalIndex)
                            } else {
                                val sizeString = getFileSize(size)
                                updateVideoComplete(originalIndex, path, sizeString)

                                // Check if compressed video lost audio
                                path?.let { compressedPath ->
                                    val compressedHasAudio = hasAudioTrack(compressedPath)
                                    if (!compressedHasAudio) {
                                        val originalUri = videoUris[index]
                                        val originalHasAudio = hasAudioTrack(originalUri)
                                        Log.w(
                                            "MainViewModel",
                                            "Compressed video has no audio. Original had audio: $originalHasAudio",
                                        )
                                    }
                                }
                            }
                            checkCompressionComplete()

                        }
                    }

                    override fun onFailure(
                        index: Int,
                        failureMessage: String,
                    ) {
                        val originalIndex = videoOriginalIndices[index]
                        viewModelScope.launch {
                            updateVideoError(originalIndex, failureMessage)
                            checkCompressionComplete()

                        }
                    }

                    override fun onProgress(
                        index: Int,
                        percent: Float,
                    ) {
                        val originalIndex = videoOriginalIndices[index]
                        viewModelScope.launch {
                            updateVideoProgress(
                                originalIndex,
                                percent / PERCENT_DIVISOR,
                                context.getString(
                                    R.string.status_compressing_percent,
                                    percent.toInt(),
                                ),
                            )
                        }
                    }

                    override fun onCancelled(index: Int) {
                        val originalIndex = videoOriginalIndices[index]
                        viewModelScope.launch {
                            updateVideoError(
                                originalIndex,
                                context.getString(R.string.status_cancelled),
                            )
                            _uiState.update { it.copy(isCompressing = false) }

                        }
                    }
                },
        )
    }

    private suspend fun runGifConversion(
        originalIndex: Int,
        uri: Uri,
    ) {
        updateVideoProgress(
            originalIndex,
            0f,
            context.getString(R.string.gif_converting_status),
        )
        val result =
            try {
                GifToMp4Converter.convert(uri, context)
            } catch (e: Exception) {
                Log.e("MainViewModel", "GIF conversion error for $uri", e)
                null
            }

        if (result == null) {
            updateVideoError(
                originalIndex,
                context.getString(R.string.gif_conversion_failed),
            )
            checkCompressionComplete()
            return
        }

        // Save the MP4 to MOVIES/lce-compressed using the library's shared
        // storage helper, matching the VideoCompressor output location.
        val savedFile =
            try {
                val fileName = "compressed_${System.currentTimeMillis()}_$originalIndex.mp4"
                val storage =
                    SharedStorageConfiguration(
                        saveAt = SaveLocation.MOVIES,
                        subFolderName = "lce-compressed",
                    )
                storage.createFileToSave(context, result.file, fileName, shouldSave = true)
            } catch (e: Exception) {
                Log.e("MainViewModel", "Failed to save converted GIF", e)
                null
            } finally {
                // The cache-dir intermediate is no longer needed regardless of outcome.
                if (!result.file.delete() && result.file.exists()) {
                    Log.w("MainViewModel", "Failed to delete GIF cache file: ${result.file.absolutePath}")
                }
            }

        if (savedFile == null) {
            updateVideoError(
                originalIndex,
                context.getString(R.string.gif_conversion_failed),
            )
        } else {
            updateVideoComplete(
                originalIndex,
                savedFile.path,
                getFileSize(savedFile.length()),
            )
        }
        checkCompressionComplete()
    }

    private fun cancelCompression() {
        VideoCompressor.cancel()
        gifJobs.forEach { it.cancel() }
        gifJobs.clear()
        _uiState.update { state ->
            state.copy(
                isCompressing = false,
                toastMessage = context.getString(R.string.compression_cancelled),
            )
        }
    }

    private fun handlePlayVideo(path: String) {
        viewModelScope.launch {
            _events.emit(MainEvent.NavigateToPlayer(path))
        }
    }

    private fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    private fun showToast(message: String) {
        _uiState.update { it.copy(toastMessage = message) }
    }

    private fun updateVideoProgress(
        index: Int,
        progress: Float,
        status: String,
    ) {
        _uiState.update { state ->
            val updatedVideos = state.videos.toMutableList()
            if (index < updatedVideos.size) {
                updatedVideos[index] =
                    updatedVideos[index].copy(
                        progress = progress,
                        newSize = status,
                    )
            }
            state.copy(videos = updatedVideos)
        }
    }

    private fun updateVideoComplete(
        index: Int,
        path: String?,
        sizeString: String,
    ) {
        _uiState.update { state ->
            val updatedVideos = state.videos.toMutableList()
            if (index < updatedVideos.size) {
                updatedVideos[index] =
                    updatedVideos[index].copy(
                        playableVideoPath = path,
                        progress = 1f,
                        newSize = sizeString,
                    )
            }
            state.copy(videos = updatedVideos)
        }
    }

    private fun updateVideoNotSaved(index: Int) {
        val status = context.getString(R.string.video_not_saved_status)
        _uiState.update { state ->
            val updatedVideos = state.videos.toMutableList()
            if (index < updatedVideos.size) {
                updatedVideos[index] =
                    updatedVideos[index].copy(
                        playableVideoPath = null,
                        progress = 1f,
                        newSize = status,
                    )
            }
            state.copy(videos = updatedVideos)
        }
    }

    private fun updateVideoError(
        index: Int,
        errorMessage: String,
    ) {
        _uiState.update { state ->
            val updatedVideos = state.videos.toMutableList()
            if (index < updatedVideos.size) {
                updatedVideos[index] =
                    updatedVideos[index].copy(
                        newSize = context.getString(R.string.status_error_format, errorMessage),
                        progress = 0f,
                        isError = true,
                    )
            }
            state.copy(videos = updatedVideos, errorMessage = errorMessage)
        }
    }

    private fun getOriginalVideoSize(uri: Uri): Long =
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                descriptor.statSize
            } ?: 0L
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to get original video size for $uri", e)
            0L
        }

    private fun deleteCompressedFile(path: String) {
        try {
            val file = java.io.File(path)
            if (file.exists() && file.delete()) {
                Log.i("MainViewModel", "Deleted compressed file: $path")
            } else {
                try {
                    val uri = path.toUri()
                    val deleted = context.contentResolver.delete(uri, null, null)
                    if (deleted > 0) {
                        Log.i("MainViewModel", "Deleted compressed file via ContentResolver: $path")
                    }
                } catch (e: Exception) {
                    Log.w("MainViewModel", "Could not delete compressed file: $path", e)
                }
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to delete compressed file: $path", e)
        }
    }

    private fun checkCompressionComplete() {
        val state = _uiState.value
        val allComplete =
            state.videos.all { video ->
                video.progress >= 1f || video.isError
            }

        if (allComplete) {
            _uiState.update { it.copy(isCompressing = false) }
            val notSavedStatus = context.getString(R.string.video_not_saved_status)
            val hasOversizedOutput = state.videos.any { it.newSize == notSavedStatus }
            if (!hasOversizedOutput) {
                showToast(context.getString(R.string.compression_complete))
            }
        }
    }

    private fun isH265Supported(): Boolean =
        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            codecList.codecInfos.any { codecInfo ->
                codecInfo.isEncoder &&
                    codecInfo.supportedTypes.any { type ->
                        type.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)
                    }
            }
        } catch (e: Exception) {
            Log.d("MainViewModel", "Error checking H.265 support: ${e.message}")
            false
        }

    private fun hasAudioTrack(path: String): Boolean {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(path)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    return true
                }
            }
            false
        } catch (e: Exception) {
            Log.e("MainViewModel", "Error checking audio track for path: $path", e)
            false
        } finally {
            extractor.release()
        }
    }

    private fun hasAudioTrack(uri: Uri): Boolean {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    return true
                }
            }
            false
        } catch (e: Exception) {
            Log.e("MainViewModel", "Error checking audio track for uri: $uri", e)
            false
        } finally {
            extractor.release()
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Cancel any ongoing compression when ViewModel is cleared
        if (_uiState.value.isCompressing) {
            VideoCompressor.cancel()
        }
        gifJobs.forEach { it.cancel() }
        gifJobs.clear()
    }
}
