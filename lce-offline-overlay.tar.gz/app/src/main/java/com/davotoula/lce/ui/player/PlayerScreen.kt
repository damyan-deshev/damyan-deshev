package com.davotoula.lce.ui.player

import android.net.Uri
import android.util.Log
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.ui.PlayerView
import com.davotoula.lce.R
import java.io.File
import java.io.IOException

private const val PLAYER_LOG_TAG = "LcePlayer"
private const val MAX_CAUSE_DEPTH = 10

/**
 * Video player screen using Media3 ExoPlayer.
 *
 * This screen provides full-screen video playback for compressed videos.
 * The video auto-plays when the screen opens and properly releases
 * resources when the user navigates away.
 *
 * @param videoPath The file path to the video to play
 * @param onBack Callback invoked when user presses the back button
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    videoPath: String,
    onBack: () -> Unit,
) {
    val context = LocalContext.current

    val exoPlayer =
        remember {
            ExoPlayer.Builder(context).build().apply {
                addListener(
                    object : Player.Listener {
                        override fun onPlayerError(error: PlaybackException) {
                            Log.e(PLAYER_LOG_TAG, "onPlayerError: ${error.errorCodeName}", error)
                            var cause: Throwable? = error.cause
                            var depth = 0
                            while (cause != null && depth < MAX_CAUSE_DEPTH) {
                                Log.e(
                                    PLAYER_LOG_TAG,
                                    "  cause[$depth] ${cause.javaClass.simpleName}: ${cause.message}",
                                    cause,
                                )
                                cause = cause.cause
                                depth++
                            }
                        }
                    },
                )
                addAnalyticsListener(
                    object : AnalyticsListener {
                        override fun onLoadError(
                            eventTime: AnalyticsListener.EventTime,
                            loadEventInfo: LoadEventInfo,
                            mediaLoadData: MediaLoadData,
                            error: IOException,
                            wasCanceled: Boolean,
                        ) {
                            Log.e(
                                PLAYER_LOG_TAG,
                                "onLoadError uri=${loadEventInfo.uri} dataType=${mediaLoadData.dataType} " +
                                    "trackType=${mediaLoadData.trackType} canceled=$wasCanceled",
                                error,
                            )
                        }
                    },
                )
                val file = File(videoPath)
                val uri = Uri.fromFile(file)
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = true
            }
        }

    // Cleanup player when leaving the screen
    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.stop()
            exoPlayer.release()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.video_player_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back),
                        )
                    }
                },
            )
        },
    ) { padding ->
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                }
            },
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(padding),
        )
    }
}
